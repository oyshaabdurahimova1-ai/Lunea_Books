# Lunea_Books — Android loyiha

Bu Android Studio uchun Kotlin + Jetpack Compose loyihasi.

## Hozirgi imkoniyatlar
- Istalgancha kitob qo‘shish
- Kitob nomi, muallifi va jami betlarini saqlash
- O‘qilgan betlarni sana bilan qayd etish
- Kitoblar bo‘yicha progress foizi
- Umumiy statistika
- O‘qish tarixi
- Kitobni tugatilgan deb belgilash
- Kitobni o‘chirish
- Ma’lumotlarni telefon xotirasida saqlash (internetsiz ishlaydi)

## APK olish
1. Kompyuterda Android Studio o‘rnating.
2. Android Studio → Open orqali `Lunea_Books_Android` papkasini tanlang.
3. Gradle sync tugashini kuting.
4. Build → Build Bundle(s) / APK(s) → Build APK(s) ni bosing.
5. APK fayli `app/build/outputs/apk/debug/app-debug.apk` ichida hosil bo‘ladi.

Eslatma: bu manba loyiha; hozircha tayyor APK emas. Ilovani Android Studio orqali APK ko‘rinishida yig‘ish kerak.
