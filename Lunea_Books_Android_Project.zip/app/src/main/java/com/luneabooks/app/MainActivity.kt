package com.luneabooks.app

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Lavender = Color(0xFF9278A8)
private val DeepLavender = Color(0xFF665078)
private val PaleLavender = Color(0xFFF3EEF7)
private val Gold = Color(0xFFB79A68)
private val Ink = Color(0xFF51475A)
private val Muted = Color(0xFF8D8493)
private val White = Color(0xFFFFFEFF)

data class ReadingEntry(val date: String, val pages: Int)
data class Book(
    val id: String,
    val title: String,
    val author: String,
    val totalPages: Int,
    val entries: List<ReadingEntry> = emptyList(),
    val finished: Boolean = false
) {
    val readPages: Int get() = entries.sumOf { it.pages }.coerceAtMost(totalPages)
    val progress: Float get() = if (totalPages > 0) readPages.toFloat() / totalPages else 0f
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LuneaApp(this) }
    }
}

private fun today(): String = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date())

private fun loadBooks(context: Context): List<Book> {
    return try {
        val raw = context.getSharedPreferences("lunea", Context.MODE_PRIVATE).getString("books", "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val entriesJson = o.optJSONArray("entries") ?: JSONArray()
            val entries = (0 until entriesJson.length()).map { j ->
                val e = entriesJson.getJSONObject(j)
                ReadingEntry(e.getString("date"), e.getInt("pages"))
            }
            Book(o.getString("id"), o.getString("title"), o.optString("author"),
                o.getInt("totalPages"), entries, o.optBoolean("finished"))
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveBooks(context: Context, books: List<Book>) {
    val arr = JSONArray()
    books.forEach { b ->
        val entries = JSONArray()
        b.entries.forEach { e -> entries.put(JSONObject().put("date", e.date).put("pages", e.pages)) }
        arr.put(JSONObject().put("id", b.id).put("title", b.title).put("author", b.author)
            .put("totalPages", b.totalPages).put("finished", b.finished).put("entries", entries))
    }
    context.getSharedPreferences("lunea", Context.MODE_PRIVATE).edit().putString("books", arr.toString()).apply()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LuneaApp(context: Context) {
    var books by remember { mutableStateOf(loadBooks(context)) }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Book?>(null) }
    var showLog by remember { mutableStateOf<Book?>(null) }

    fun update(next: List<Book>) {
        books = next
        saveBooks(context, next)
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Lavender, onPrimary = White, secondary = Gold,
            background = PaleLavender, surface = White, onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = PaleLavender,
            topBar = {
                Column(Modifier.fillMaxWidth().background(White).padding(horizontal = 22.dp, vertical = 15.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Lunea_Books", fontSize = 25.sp, color = DeepLavender, fontWeight = FontWeight.Light)
                            Text("Your personal reading journal", fontSize = 11.sp, color = Muted, letterSpacing = 1.sp)
                        }
                        Icon(Icons.Default.AutoStories, null, tint = Gold, modifier = Modifier.size(29.dp))
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = White, contentColor = DeepLavender) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.MenuBook, null) }, label = { Text("Kitoblar") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.Insights, null) }, label = { Text("Statistika") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.History, null) }, label = { Text("Tarix") })
                }
            },
            floatingActionButton = {
                if (tab == 0) FloatingActionButton(onClick = { showAdd = true }, containerColor = Lavender, contentColor = White) {
                    Icon(Icons.Default.Add, "Kitob qo‘shish")
                }
            }
        ) { padding ->
            when (tab) {
                0 -> BooksScreen(books, Modifier.padding(padding),
                    onLog = { showLog = it }, onOpen = { selected = it },
                    onFinish = { b -> update(books.map { if (it.id == b.id) it.copy(finished = true) else it }) })
                1 -> StatsScreen(books, Modifier.padding(padding))
                else -> HistoryScreen(books, Modifier.padding(padding))
            }
        }

        if (showAdd) AddBookDialog(onDismiss = { showAdd = false }, onSave = { title, author, pages ->
            update(books + Book(UUID.randomUUID().toString(), title, author, pages))
            showAdd = false
        })
        if (showLog != null) LogPagesDialog(showLog!!, onDismiss = { showLog = null }, onSave = { count ->
            val b = showLog!!
            val next = books.map { if (it.id == b.id) it.copy(entries = it.entries + ReadingEntry(today(), count)) else it }
            update(next); showLog = null
        })
        if (selected != null) BookDetailDialog(selected!!, onDismiss = { selected = null },
            onLog = { showLog = selected; selected = null },
            onFinish = { b -> update(books.map { if (it.id == b.id) it.copy(finished = true) else it }); selected = null },
            onDelete = { b -> update(books.filterNot { it.id == b.id }); selected = null })
    }
}

@Composable
fun BooksScreen(books: List<Book>, modifier: Modifier, onLog: (Book) -> Unit,
                onOpen: (Book) -> Unit, onFinish: (Book) -> Unit) {
    val active = books.filterNot { it.finished }
    val finished = books.filter { it.finished }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Kitob javonim", fontSize = 22.sp, color = DeepLavender, fontWeight = FontWeight.Light)
                    Text("${books.size} ta kitob • ${finished.size} ta tugatilgan", color = Muted, fontSize = 12.sp)
                }
                Text("✧", color = Gold, fontSize = 27.sp)
            }
        }
        if (books.isEmpty()) item { EmptyCard() }
        if (active.isNotEmpty()) item { SectionLabel("O‘qilayotgan kitoblar") }
        items(active, key = { it.id }) { b ->
            BookCard(b, onClick = { onOpen(b) }, onLog = { onLog(b) })
        }
        if (finished.isNotEmpty()) item { SectionLabel("Tugatilgan kitoblar") }
        items(finished, key = { it.id }) { b -> BookCard(b, onClick = { onOpen(b) }, onLog = { onLog(b) }) }
        item { Spacer(Modifier.height(10.dp)) }
    }
}

@Composable
fun EmptyCard() {
    Card(colors = CardDefaults.cardColors(containerColor = White), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.LocalFlorist, null, tint = Gold, modifier = Modifier.size(38.dp))
            Spacer(Modifier.height(8.dp))
            Text("Javoningiz hali bo‘sh", color = DeepLavender, fontSize = 17.sp)
            Text("＋ tugmasi orqali ilk kitobingizni qo‘shing", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(text, color = DeepLavender, fontSize = 15.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(top = 5.dp))
}

@Composable
fun BookCard(book: Book, onClick: () -> Unit, onLog: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = White),
        shape = RoundedCornerShape(19.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(43.dp).background(PaleLavender, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.MenuBook, null, tint = Lavender)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(book.title, color = DeepLavender, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text(book.author.ifBlank { "Muallif ko‘rsatilmagan" }, color = Muted, fontSize = 12.sp)
                }
                if (book.finished) Icon(Icons.Default.CheckCircle, null, tint = Gold)
                else Text("${(book.progress * 100).toInt()}%", color = Gold, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(13.dp))
            LinearProgressIndicator(progress = { book.progress }, modifier = Modifier.fillMaxWidth().height(6.dp),
                color = Lavender, trackColor = PaleLavender)
            Spacer(Modifier.height(7.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${book.readPages} / ${book.totalPages} bet", color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                if (!book.finished) TextButton(onClick = onLog, contentPadding = PaddingValues(horizontal = 8.dp)) {
                    Icon(Icons.Default.Edit, null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp)); Text("Bet kiritish", fontSize = 12.sp)
                } else Text("Tugatildi ✓", color = Gold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun StatsScreen(books: List<Book>, modifier: Modifier) {
    val total = books.sumOf { it.totalPages }
    val read = books.sumOf { it.readPages }
    val percent = if (total == 0) 0 else (read * 100 / total)
    val sessions = books.sumOf { it.entries.size }
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Text("O‘qish statistikasi", fontSize = 22.sp, color = DeepLavender, fontWeight = FontWeight.Light)
        Card(colors = CardDefaults.cardColors(containerColor = White), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Umumiy o‘qish jarayoni", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Text("$percent%", color = DeepLavender, fontSize = 42.sp, fontWeight = FontWeight.Light)
                LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp),
                    color = Lavender, trackColor = PaleLavender)
                Spacer(Modifier.height(8.dp))
                Text("$read / $total bet", color = Muted, fontSize = 12.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("Kitoblar", books.size.toString(), Modifier.weight(1f), Icons.Default.MenuBook)
            StatTile("Tugatilgan", books.count { it.finished }.toString(), Modifier.weight(1f), Icons.Default.CheckCircle)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("O‘qilgan bet", read.toString(), Modifier.weight(1f), Icons.Default.AutoStories)
            StatTile("O‘qish qaydi", sessions.toString(), Modifier.weight(1f), Icons.Default.History)
        }
        Text("Har bir o‘qilgan bet — yangi marraga yaqinlashish.", color = Gold, fontSize = 12.sp)
    }
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp)) {
            Icon(icon, null, tint = Gold)
            Spacer(Modifier.height(8.dp))
            Text(value, color = DeepLavender, fontSize = 25.sp, fontWeight = FontWeight.Light)
            Text(label, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun HistoryScreen(books: List<Book>, modifier: Modifier) {
    val history = books.flatMap { b -> b.entries.map { Triple(b.title, it.date, it.pages) } }
        .sortedByDescending { it.second }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("O‘qish tarixi", fontSize = 22.sp, color = DeepLavender, fontWeight = FontWeight.Light) }
        if (history.isEmpty()) item {
            Card(colors = CardDefaults.cardColors(containerColor = White), shape = RoundedCornerShape(20.dp)) {
                Text("Hozircha o‘qish qaydlari yo‘q. Kitobingizdan bet o‘qib, qayd kiriting.",
                    modifier = Modifier.padding(22.dp), color = Muted, fontSize = 13.sp)
            }
        }
        items(history) { item ->
            Card(colors = CardDefaults.cardColors(containerColor = White), shape = RoundedCornerShape(15.dp)) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.EventNote, null, tint = Gold)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.first, color = DeepLavender, fontSize = 14.sp)
                        Text(item.second, color = Muted, fontSize = 11.sp)
                    }
                    Text("+${item.third} bet", color = Lavender, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun AddBookDialog(onDismiss: () -> Unit, onSave: (String, String, Int) -> Unit) {
    var title by remember { mutableStateOf("") }
    var author by remember { mutableStateOf("") }
    var pages by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, containerColor = White,
        title = { Text("Yangi kitob", color = DeepLavender, fontWeight = FontWeight.Light) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(title, { title = it; error = false }, label = { Text("Kitob nomi *") }, singleLine = true)
                OutlinedTextField(author, { author = it }, label = { Text("Muallif") }, singleLine = true)
                OutlinedTextField(pages, { pages = it.filter(Char::isDigit) }, label = { Text("Jami betlar *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                if (error) Text("Kitob nomi va betlar sonini to‘g‘ri kiriting.", color = Color.Red, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = {
            val n = pages.toIntOrNull()
            if (title.isNotBlank() && n != null && n > 0) onSave(title.trim(), author.trim(), n) else error = true
        }) { Text("Saqlash", color = Lavender) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish", color = Muted) } })
}

@Composable
fun LogPagesDialog(book: Book, onDismiss: () -> Unit, onSave: (Int) -> Unit) {
    var pages by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    val remaining = (book.totalPages - book.readPages).coerceAtLeast(0)
    AlertDialog(onDismissRequest = onDismiss, containerColor = White,
        title = { Text("O‘qilgan betlarni qayd etish", color = DeepLavender, fontWeight = FontWeight.Light) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(book.title, color = Muted, fontSize = 13.sp)
                Text("Bugungi sana: ${today()}", color = Gold, fontSize = 12.sp)
                Text("Qolgan betlar: $remaining", color = Muted, fontSize = 12.sp)
                OutlinedTextField(pages, { pages = it.filter(Char::isDigit); error = false },
                    label = { Text("Bugun nechta bet o‘qidingiz?") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                if (error) Text("1 dan $remaining gacha son kiriting.", color = Color.Red, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = {
            val n = pages.toIntOrNull()
            if (n != null && n in 1..remaining) onSave(n) else error = true
        }) { Text("Qayd etish", color = Lavender) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish", color = Muted) } })
}

@Composable
fun BookDetailDialog(book: Book, onDismiss: () -> Unit, onLog: () -> Unit,
                     onFinish: (Book) -> Unit, onDelete: (Book) -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, containerColor = White,
        title = { Text(book.title, color = DeepLavender, fontWeight = FontWeight.Light) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Muallif: ${book.author.ifBlank { "Ko‘rsatilmagan" }}", color = Muted, fontSize = 12.sp)
                Text("${book.readPages} / ${book.totalPages} bet • ${(book.progress * 100).toInt()}%", color = Lavender)
                Text("O‘qish qaydlari: ${book.entries.size} ta", color = Muted, fontSize = 12.sp)
                if (book.entries.isNotEmpty()) {
                    book.entries.takeLast(5).asReversed().forEach {
                        Text("${it.date}  •  ${it.pages} bet", color = Muted, fontSize = 11.sp)
                    }
                }
            }
        },
        confirmButton = {
            Row {
                if (!book.finished) TextButton(onClick = { onLog() }) { Text("Bet kiritish", color = Lavender) }
                TextButton(onClick = { onDelete(book) }) { Text("O‘chirish", color = Color(0xFFB66B72)) }
                if (!book.finished) TextButton(onClick = { onFinish(book) }) { Text("Tugatildi", color = Gold) }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Yopish", color = Muted) } })
}
